# Auto Checkin Honkai Impact 3
How to use: 
+ `Code` -> `Download Zip` and extract in your computer.    
+ Login to [web](https://webstatic-sea.mihoyo.com/bbs/event/signin-bh3/index.html?act_id=e202110291205111)  
+ Goto `chrome://extensions/`, enable `developer mode`. Click `Load Unpacked` and navigate to `/src/` was extract  
+ Open chrome every day
________________________
Security risk? Just check source code.
________________________
Source from [it](https://github.com/tqk2811/AutoCheckinGI)
